const buttons = document.querySelectorAll('button'),
    images = document.querySelectorAll('.images');

buttons.forEach(button => {
    button.addEventListener('click', e => {
        images.forEach(image => image.style.display = 'none');
        button.nextElementSibling.lastElementChild.style.display = 'inline-block';
    });
});



// let submit1 = document.getElementById("submit1");
// let result1 = document.getElementById("result1");

// submit1.addEventListener("click", (e) => {
//     e.preventDefault();

//     result1.innerHTML ="<img src= img_noel/jour1.gif>"

// });


// let submit2 = document.getElementById("submit2");
// let result2 = document.getElementById("result2");

// submit2.addEventListener("click", (e) => {
//     e.preventDefault();

//     result2.innerHTML ="<img src= img_noel/jour2.png>"

// });


// let submit3 = document.getElementById("submit3");
// let result3 = document.getElementById("result3");

// submit3.addEventListener("click", (e) => {
//     e.preventDefault();

//     result3.innerHTML ="<img src= img_noel/jour3.png>"

// });


// let submit4 = document.getElementById("submit4");
// let result4 = document.getElementById("result4");

// submit4.addEventListener("click", (e) => {
//     e.preventDefault();

//     result4.innerHTML ="<img src= img_noel/jour4.png>"

// });


// let submit5 = document.getElementById("submit5");
// let result5 = document.getElementById("result5");

// submit5.addEventListener("click", (e) => {
//     e.preventDefault();

//     result5.innerHTML ="<img src= img_noel/jour5.gif>"

// });


// let submit6 = document.getElementById("submit6");
// let result6 = document.getElementById("result6");

// submit6.addEventListener("click", (e) => {
//     e.preventDefault();

//     result6.innerHTML ="<img src= img_noel/jour6.png>"

// });


// let submit7 = document.getElementById("submit7");
// let result7 = document.getElementById("result7");

// submit7.addEventListener("click", (e) => {
//     e.preventDefault();

//     result7.innerHTML ="<img src= img_noel/jour7.png>"

// });

// let submit8 = document.getElementById("submit8");
// let result8 = document.getElementById("result8");

// submit8.addEventListener("click", (e) => {
//     e.preventDefault();

//     result8.innerHTML ="<img src= img_noel/jour8.gif>"

// });


// let submit9 = document.getElementById("submit9");
// let result9 = document.getElementById("result9");

// submit9.addEventListener("click", (e) => {
//     e.preventDefault();

//     result9.innerHTML ="<img class='images' src= img_noel/jour9.gif>"

// });

// let submit10 = document.getElementById("submit10");
// let result10 = document.getElementById("result10");

// submit10.addEventListener("click", (e) => {
//     e.preventDefault();

//     result10.innerHTML ="<img class='images' src= img_noel/jour10.png>"

// });

// let submit11 = document.getElementById("submit11");
// let result11 = document.getElementById("result11");

// submit11.addEventListener("click", (e) => {
//     e.preventDefault();

//     result11.innerHTML ="<img src= img_noel/jour11.png>"

// });

// let submit12 = document.getElementById("submit12");
// let result12 = document.getElementById("result12");

// submit12.addEventListener("click", (e) => {
//     e.preventDefault();

//     result12.innerHTML ="<img src= img_noel/jour12.gif>"

// });


// let submit13 = document.getElementById("submit13");
// let result13 = document.getElementById("result13");

// submit13.addEventListener("click", (e) => {
//     e.preventDefault();

//     result13.innerHTML ="<img src= img_noel/jour13.png>"

// });


// let submit14 = document.getElementById("submit14");
// let result14 = document.getElementById("result14");

// submit14.addEventListener("click", (e) => {
//     e.preventDefault();

//     result14.innerHTML ="<img src= img_noel/jour14.png>"

// });



// let submit15 = document.getElementById("submit15");
// let result15 = document.getElementById("result15");

// submit15.addEventListener("click", (e) => {
//     e.preventDefault();

//     result15.innerHTML ="<img src= img_noel/jour15.gif>"

// });


// let submit16 = document.getElementById("submit16");
// let result16 = document.getElementById("result16");

// submit16.addEventListener("click", (e) => {
//     e.preventDefault();

//     result16.innerHTML ="<img src= img_noel/jour16.png>"

// });


// let submit17= document.getElementById("submit17");
// let result17 = document.getElementById("result17");

// submit17.addEventListener("click", (e) => {
//     e.preventDefault();

//     result17.innerHTML ="<img src= img_noel/jour17.png>"

// });


// let submit18 = document.getElementById("submit18");
// let result18 = document.getElementById("result18");

// submit18.addEventListener("click", (e) => {
//     e.preventDefault();

//     result18.innerHTML ="<img src= img_noel/jour18.gif>"

// });


// let submit19 = document.getElementById("submit19");
// let result19 = document.getElementById("result19");

// submit19.addEventListener("click", (e) => {
//     e.preventDefault();

//     result19.innerHTML ="<img src= img_noel/jour19.png>"

// });


// let submit20= document.getElementById("submit20");
// let result20 = document.getElementById("result20");

// submit20.addEventListener("click", (e) => {
//     e.preventDefault();

//     result20.innerHTML ="<img src= img_noel/jour20.png>"

// });


// let submit21= document.getElementById("submit21");
// let result21 = document.getElementById("result21");

// submit21.addEventListener("click", (e) => {
//     e.preventDefault();

//     result21.innerHTML ="<img src= img_noel/jour21.gif>"

// });

// let submit22 = document.getElementById("submit22");
// let result22 = document.getElementById("result22");

// submit22.addEventListener("click", (e) => {
//     e.preventDefault();

//     result22.innerHTML ="<img src= img_noel/jour22.png>"

// });

// let submit23 = document.getElementById("submit23");
// let result23 = document.getElementById("result23");

// submit23.addEventListener("click", (e) => {
//     e.preventDefault();

//     result23.innerHTML ="<img src= img_noel/jour23.gif>"

// });



// let submit24 = document.getElementById("submit24");
// let result24 = document.getElementById("result24");

// submit24.addEventListener("click", (e) => {
//     e.preventDefault();

//     result24.innerHTML ="<img src= img_noel/jour24.gif>"

// });








// let submit25 = document.getElementById("submit25");
// let result25= document.getElementById("result25");

// submit25.addEventListener("click", (e) => {
//     e.preventDefault();

//     result25.innerHTML =(`<video src= img_noel/jour25.mp4 width="500" height="280" controls></video>`)

// });